# Kandel — Brand Kit

**Kandel** /KAN-del/ — dari *candlestick*. Mark-nya huruf **K** yang dibentuk dari satu
candle: wick + body jadi batang K, dua lengan jadi arah pergerakan harga.

Tagline: **Trading Journal** · Positioning line: *"Catat setiap entry, exit, dan alasan di baliknya."*

Domain yang layak dicek: `kandel.app` · `kandel.io` · `kandel.id` · `usekandel.com`

---

## Isi folder

```
kandel-brand-sheet.html      ← buka ini dulu. Brand sheet lengkap, offline, font ter-embed.

svg/
  kandel-logo-dark.svg         lockup utama (background gelap)
  kandel-logo-light.svg        lockup untuk background terang / invoice
  kandel-logo-mono-white.svg   satu warna putih
  kandel-logo-mono-black.svg   satu warna hitam (mis. di atas yellow)
  kandel-wordmark-dark.svg     lockup tanpa tagline
  kandel-mark.svg              mark saja, duotone
  kandel-mark-mono-white.svg   /  kandel-mark-mono-black.svg
  kandel-mark-pnl.svg          varian aksen hijau/merah — marketing saja, bukan UI
  kandel-icon.svg              app icon (squircle + border)

png/
  icon-512 / 256 / 192 / 128 / 64.png
  icon-maskable-512.png        safe zone Android adaptive icon
  apple-touch-icon-180.png     tanpa rounding (iOS masking sendiri)
  kandel-logo-dark@2x.png  /  kandel-logo-light@2x.png   (1200px, transparan)

favicon/
  favicon.ico                  16 + 32 + 48 dalam satu file
  favicon.svg                  vektor, dipakai browser modern
  favicon-16/32/48/64.png      16 & 32 pakai geometri lebih tebal biar kebaca di tab

code/
  kandel-tokens.css            CSS variable lengkap + dark & light theme
  tailwind.config.snippet.js   tinggal tempel ke theme.extend
  head-snippet.html            tag favicon, manifest, font, meta
  site.webmanifest             siap untuk PWA

source/
  gen.py                       generator semua asset di atas
  fonts/                       Space Grotesk 500 & 700 (OFL)
```

## Ganti nama tanpa gambar ulang

Buka `source/gen.py`, ubah `BRAND_NAME` dan `TAGLINE` di baris atas, lalu:

```bash
pip install cairosvg fonttools pillow
python source/gen.py
```

Kalau nama barunya tidak diawali huruf K, mark-nya perlu digambar ulang —
bilang saja, geometrinya ada di fungsi `mark()`.

## Palet

| Token | Hex | Dipakai untuk |
|---|---|---|
| Yellow | `#FCD535` | Aksi utama, mark, focus ring |
| Yellow Deep | `#F0B90B` | Hover / pressed, sisi kedua mark |
| Ink | `#0B0E11` | Canvas aplikasi |
| Surface | `#181A20` | Card, panel, body tabel |
| Raised | `#1E2329` | Modal, dropdown, header tabel |
| Line | `#2B3139` | Border, divider, grid chart |
| Text | `#EAECEF` | Teks utama |
| Muted | `#848E9C` | Label, caption, axis |
| Long | `#0ECB81` | Buy / win / profit — khusus P&L |
| Short | `#F6465D` | Sell / loss — khusus P&L |

Aturan: yellow hanya untuk aksi utama dan identitas. Hijau dan merah hanya untuk P&L dan
arah posisi — status sistem pakai Info `#4A90E2` / Warning `#F0B90B`.

## Tipografi

- Display: **Space Grotesk** 700 — wordmark, heading, angka besar
- Body/UI: **Inter** — label, form, deskripsi
- Angka: **JetBrains Mono** dengan `tabular-nums` — harga, lot, R, persen

## Aturan pakai logo

- Clear space semua sisi = lebar body candle
- Mark berdiri sendiri sampai 16 px; lockup penuh minimum 120 px lebar
- Jangan diregangkan, dimiringkan, diberi shadow, atau ditaruh di atas foto tanpa lapisan gelap
- Jangan ganti warna mark di luar varian yang sudah disediakan

Font Space Grotesk & Inter & JetBrains Mono = SIL Open Font License, bebas dipakai komersial.
