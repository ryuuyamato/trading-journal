// tailwind.config.js — extend bagian theme
export default {
  theme: {
    extend: {
      colors: {
        kandel: {
          yellow:  '#FCD535',
          deep:    '#F0B90B',
          dim:     '#C99400',
          bg:      '#0B0E11',
          surface: '#181A20',
          raised:  '#1E2329',
          hover:   '#252930',
          line:    '#2B3139',
          text:    '#EAECEF',
          text2:   '#B7BDC6',
          muted:   '#848E9C',
          long:    '#0ECB81',
          short:   '#F6465D',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'ui-sans-serif', 'system-ui'],
        sans:    ['Inter', 'ui-sans-serif', 'system-ui'],
        mono:    ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: { card: '16px' },
      boxShadow: { focus: '0 0 0 3px rgba(252,213,53,.25)' },
    },
  },
}
