#!/usr/bin/env python3
"""Kandel brand asset generator. Ganti BRAND_NAME lalu jalankan ulang."""
import os, math
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.misc.transform import Transform
import cairosvg

BRAND_NAME = "Kandel"
TAGLINE = "TRADING JOURNAL"
OUT = "/mnt/user-data/outputs/kandel-brand"
os.makedirs(OUT, exist_ok=True)

# ---------- palette ----------
YEL      = "#FCD535"   # primary
YEL_DEEP = "#F0B90B"   # secondary / hover
INK      = "#0B0E11"   # canvas
SURF     = "#181A20"
LONG     = "#0ECB81"
SHORT    = "#F6465D"
WHITE    = "#FFFFFF"

FONT_700 = "fonts/SpaceGrotesk-700.ttf"
FONT_500 = "fonts/SpaceGrotesk-500.ttf"

# ---------- wordmark: font glyphs -> svg path ----------
def text_path(text, font_file, cap_height, tracking=0.0):
    """Return (path_d, width). Baseline at y=0, starts at x=0, y grows downward."""
    f = TTFont(font_file)
    upem = f["head"].unitsPerEm
    cap = getattr(f["OS/2"], "sCapHeight", 700) or 700
    scale = cap_height / cap
    gs = f.getGlyphSet()
    cmap = f.getBestCmap()
    hmtx = f["hmtx"]
    x = 0.0
    d = []
    for ch in text:
        gname = cmap.get(ord(ch))
        if gname is None:
            x += 0.35 * upem
            continue
        pen = SVGPathPen(gs)
        # flip Y (font up-positive -> svg down-positive) and scale
        tpen = TransformPen(pen, Transform(scale, 0, 0, -scale, x * scale, 0))
        gs[gname].draw(tpen)
        seg = pen.getCommands()
        if seg:
            d.append(seg)
        x += hmtx[gname][0] + tracking * upem
    x -= tracking * upem
    return " ".join(d), x * scale

# ---------- mark geometry (art space ~66 x 77, origin shifted to 0,0) ----------
MX, MY = 18.0, 11.5           # bbox origin in raw art coords
MW, MH = 66.0, 77.0

def mark(stem=YEL, arms=YEL_DEEP, size=MH, x=0.0, y=0.0):
    """K built from a candlestick: wick + body form the stem, arms are the move."""
    s = size / MH
    return f'''<g transform="translate({x:.2f},{y:.2f}) scale({s:.5f}) translate({-MX},{-MY})">
    <g stroke="{arms}" stroke-width="13" stroke-linecap="round" fill="none">
      <path d="M42 50 L78 18"/>
      <path d="M42 50 L78 82"/>
    </g>
    <rect x="23.5" y="12" width="7" height="76" rx="3.5" fill="{stem}"/>
    <rect x="18" y="26" width="18" height="48" rx="6" fill="{stem}"/>
  </g>'''

def svg(w, h, body, bg=None, extra=""):
    b = f'<rect width="{w}" height="{h}" fill="{bg}"/>' if bg else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w:.2f} {h:.2f}" '
            f'width="{w:.2f}" height="{h:.2f}" fill="none">{extra}{b}{body}</svg>')

def write(name, content):
    p = os.path.join(OUT, name)
    with open(p, "w") as fh:
        fh.write(content)
    return p

def png(svg_str, name, w, h):
    cairosvg.svg2png(bytestring=svg_str.encode(), write_to=os.path.join(OUT, name),
                     output_width=w, output_height=h)

# ---------- 1. mark only ----------
MARK_SIZE = 512
mw = MARK_SIZE * MW / MH
write("mark/kandel-mark.svg", "") if False else None
os.makedirs(f"{OUT}/svg", exist_ok=True)
os.makedirs(f"{OUT}/png", exist_ok=True)
os.makedirs(f"{OUT}/favicon", exist_ok=True)

mark_svg = svg(mw, MARK_SIZE, mark(size=MARK_SIZE))
write("svg/kandel-mark.svg", mark_svg)
write("svg/kandel-mark-mono-white.svg", svg(mw, MARK_SIZE, mark(WHITE, WHITE, MARK_SIZE)))
write("svg/kandel-mark-mono-black.svg", svg(mw, MARK_SIZE, mark(INK, INK, MARK_SIZE)))
write("svg/kandel-mark-pnl.svg",
      svg(mw, MARK_SIZE, f'''<g transform="scale({MARK_SIZE/MH:.5f}) translate({-MX},{-MY})">
      <path d="M42 50 L78 18" stroke="{LONG}" stroke-width="13" stroke-linecap="round"/>
      <path d="M42 50 L78 82" stroke="{SHORT}" stroke-width="13" stroke-linecap="round"/>
      <rect x="23.5" y="12" width="7" height="76" rx="3.5" fill="{YEL}"/>
      <rect x="18" y="26" width="18" height="48" rx="6" fill="{YEL}"/></g>'''))

# ---------- 2. app icon (squircle badge) ----------
def icon(size=512, pad_ratio=0.30, bg1=INK, bg2=SURF, stem=YEL, arms=YEL_DEEP, radius=0.2237):
    inner = size * (1 - pad_ratio)
    mh = inner
    mwi = inner * MW / MH
    gx = (size - mwi) / 2
    gy = (size - mh) / 2
    grad = (f'<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">'
            f'<stop offset="0" stop-color="{bg2}"/><stop offset="1" stop-color="{bg1}"/>'
            f'</linearGradient></defs>')
    body = (f'<rect width="{size}" height="{size}" rx="{size*radius:.2f}" fill="url(#bg)"/>'
            f'<rect x="0.5" y="0.5" width="{size-1}" height="{size-1}" rx="{size*radius:.2f}" '
            f'fill="none" stroke="#2B3139" stroke-width="{max(1,size*0.004):.2f}"/>'
            + mark(stem, arms, mh, gx, gy))
    return svg(size, size, body, extra=grad)

write("svg/kandel-icon.svg", icon(512))
for s in (512, 256, 192, 128, 64):
    png(icon(512), f"png/icon-{s}.png", s, s)
png(icon(512, radius=0.0), "png/apple-touch-icon-180.png", 180, 180)      # iOS masks it itself
png(icon(512, pad_ratio=0.44, radius=0.5), "png/icon-maskable-512.png", 512, 512)

# ---------- 3. favicon (tanpa squircle, mark lebih tebal biar kebaca 16px) ----------
def mark_compact(stem, arms, size, x, y):
    """Versi tebal buat 16-32px: wick lebih pendek, body lebih lebar."""
    s = size / MH
    return f'''<g transform="translate({x:.2f},{y:.2f}) scale({s:.5f}) translate({-MX},{-MY})">
    <g stroke="{arms}" stroke-width="15" stroke-linecap="round" fill="none">
      <path d="M42 50 L77 20"/>
      <path d="M42 50 L77 80"/>
    </g>
    <rect x="22" y="18" width="10" height="64" rx="5" fill="{stem}"/>
    <rect x="17" y="28" width="20" height="44" rx="6" fill="{stem}"/>
  </g>'''

def favicon_svg(size=64, compact=False):
    inner = size * 0.76
    mwi = inner * MW / MH
    fn = mark_compact if compact else mark
    return svg(size, size,
               f'<rect width="{size}" height="{size}" rx="{size*0.22:.2f}" fill="{INK}"/>'
               + fn(YEL, YEL_DEEP, inner, (size-mwi)/2, size*0.12))

write("favicon/favicon.svg", favicon_svg(64))
for s in (16, 32):
    png(favicon_svg(64, compact=True), f"favicon/favicon-{s}.png", s, s)
for s in (48, 64):
    png(favicon_svg(64), f"favicon/favicon-{s}.png", s, s)

from PIL import Image
imgs = [Image.open(f"{OUT}/favicon/favicon-{s}.png").convert("RGBA") for s in (16, 32, 48)]
imgs[0].save(f"{OUT}/favicon/favicon.ico", format="ICO",
             sizes=[(16, 16), (32, 32), (48, 48)], append_images=imgs[1:])

# ---------- 4. horizontal lockup ----------
def lockup(stem, arms, word_color, tag_color=None, with_tagline=True, mark_h=88.0):
    cap = mark_h * 0.545
    d, wdt = text_path(BRAND_NAME, FONT_700, cap, tracking=-0.018)
    gap = mark_h * 0.25
    mwi = mark_h * MW / MH
    baseline = mark_h / 2 + cap / 2
    body = mark(stem, arms, mark_h, 0, 0)
    body += f'<path transform="translate({mwi+gap:.2f},{baseline:.2f})" d="{d}" fill="{word_color}"/>'
    W = mwi + gap + wdt
    H = mark_h
    if with_tagline:
        tcap = cap * 0.255
        td, twd = text_path(TAGLINE, FONT_500, tcap, tracking=0.20)
        ty = baseline + cap * 0.52
        body += f'<path transform="translate({mwi+gap+1:.2f},{ty:.2f})" d="{td}" fill="{tag_color}"/>'
        W = max(W, mwi + gap + twd)
        H = max(H, ty + tcap * 0.4)
    return svg(W, H, body)

write("svg/kandel-logo-dark.svg",  lockup(YEL, YEL_DEEP, "#EAECEF", "#848E9C"))
write("svg/kandel-logo-light.svg", lockup(YEL_DEEP, YEL_DEEP, INK, "#5E6673"))
write("svg/kandel-logo-mono-white.svg", lockup(WHITE, WHITE, WHITE, WHITE, with_tagline=False))
write("svg/kandel-logo-mono-black.svg", lockup(INK, INK, INK, INK, with_tagline=False))
write("svg/kandel-wordmark-dark.svg", lockup(YEL, YEL_DEEP, "#EAECEF", None, with_tagline=False))

for name, s in [("kandel-logo-dark", lockup(YEL, YEL_DEEP, "#EAECEF", "#848E9C")),
                ("kandel-logo-light", lockup(YEL_DEEP, YEL_DEEP, INK, "#5E6673"))]:
    png(s, f"png/{name}@2x.png", 1200, None) if False else None
    import re
    m = re.search(r'viewBox="0 0 ([\d.]+) ([\d.]+)"', s)
    W, H = float(m.group(1)), float(m.group(2))
    png(s, f"png/{name}@2x.png", 1200, int(1200 * H / W))

print("done ->", OUT)
